from picamera.array import PiRGBArray
from picamera import PiCamera

from pyimagesearch import imutils

import time
import cv2

import serial
import time
import string
import random

ser = serial.Serial('/dev/ttyACM1', 115200)


# initialize the camera and grab a reference to the raw camera capture
camera = PiCamera()
camera.resolution = (1024, 768)
camera.framerate = 8
rawCapture = PiRGBArray(camera, size=(1024, 768))

# allow the camera to warmup
time.sleep(1)


goleft =0
goright = 0
goup = 0
godown = 0
jump =0
vdirection = ""
hdirection = ""


xreswidth = int(1024)
xreshalf = int(round( xreswidth /2) )
xres10p = int(round( xreswidth /32) )

yreswidth = int(round( xreswidth * float(480.0/640) ) )
yreshalf = int(round( yreswidth /2) )
yres10p = int(round( yreswidth /32) )
print xreswidth,xreshalf,xres10p
print yreswidth,yreshalf,yres10p

# capture frames from the camera
for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):

	crs = open('/home/pi/streamvideo/color.dat','r')
	ColorRange={}
	k1 = 0
	k2 = 0
	line = crs.read().strip()
	for pair in line.split(';'):
		(key,value) = pair.split('=')
		ColorRange[key] = int(value)
		
	redLower = (ColorRange['BlueMin'], ColorRange['GreenMin'], ColorRange['RedMin'])
	redUpper = (ColorRange['BlueMax'], ColorRange['GreenMax'], ColorRange['RedMax'])
	
	image = frame.array
	
	frame = imutils.resize(image, width = xreswidth)
	# gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

	mask = cv2.inRange(hsv, redLower, redUpper)
	mask = cv2.erode(mask, None, iterations=2)
	mask = cv2.dilate(mask, None, iterations=2)
	
	cnts = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL,
	cv2.CHAIN_APPROX_SIMPLE)[-2]
	center = None
	x=0
	y=0
	if len(cnts) > 0:
		# find the largest contour in the mask, then use
		# it to compute the minimum enclosing circle and
		# centroid
		c = max(cnts, key=cv2.contourArea)
		((x, y), radius) = cv2.minEnclosingCircle(c)
		M = cv2.moments(c)
		center = (int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"]))
 
		# only proceed if the radius meets a minimum size
		if radius > xres10p/2:
			# draw the circle and centroid on the frame,
			# then update the list of tracked points
			cv2.circle(frame, (int(x), int(y)), int(radius),
				(0, 255, 255), 2)
			# cv2.circle(frame, center, 5, (0, 0, 255), -1)
		
	print "x:", int(x), goleft, " -- Y:", int(y), goup
	
	if ( (int(x) > (xreshalf+xres10p) and int(x)>0) or (x==0 and hdirection == "xL") ):
		
		jump = x-xreshalf
		jump = int(round(jump / xres10p))
		if (jump>8) : jump = 8
		if (x==0 and hdirection == "L") : jump = 3
		
		goleft = goleft+jump
		if (goleft>60) : goleft = 60
		hdirection = "L"
		if goleft>0 :
			input = "AD" + chr(65+goleft) +",.";
		if goleft<0 :
			input = "AE" + chr(65+abs(goleft)) +",.";
			
		ser.write(input)
		time.sleep(0.1)
		
		
	if (int(x) < (xreshalf-xres10p) and int(x)>0) or (x==0 and hdirection == "xR") :
		jump = x
		jump = int(round(jump / xres10p))
		if (jump>8) : jump = 8
		if (x==0 and hdirection == "R") : jump = 3

		goleft = goleft - jump
		if (goleft<-60) : goleft = -60
		hdirection = "R"
		if goleft>0 :
			input = "AD" + chr(65+goleft) +",.";
		if goleft<0 :
			input = "AE" + chr(65+abs(goleft)) +",.";
		
		ser.write(input)
		time.sleep(0.1)
		
	if (int(y)==0) :
		input = "BDA,.";
		goup = 0;
		time.sleep(0.1)
		

	if ( (int(y) > (yreshalf+yres10p) and int(y)>0) or (y==0 and vdirection == "xU") ) :
		jump = y-yreshalf
		jump = int(round(jump / (yres10p*2)))
		if (jump>5) : jump = 3
		if (y==0 and vdirection == "U") : jump = 1

		goup = goup - jump
		if (goup<-30) : goup = -30
		vdirection = "U"
		if goup>0 :
			input = "BE" + chr(65+goup) +",.";
		if goup<0 :
			input = "BD" + chr(65+abs(goup)) +",.";
			
		ser.write(input)
		time.sleep(0.1)

	if ( (int(y) < (yreshalf-yres10p) and int(y)>0) or (y==0 and vdirection=="xD")) :
		jump = y
		jump = int(round(jump / (yres10p*2)))
		if (jump>5) : jump = 3
		if (y==0 and vdirection == "D") : jump = 1

		goup = goup+jump
		if (goup>30) : goup = 30
		vdirection = "D"
		if goup>0 :
			input = "BE" + chr(65+goup) +",.";
		if goup<0 :
			input = "BD" + chr(65+abs(goup)) +",.";
		
		ser.write(input)
		time.sleep(0.1)

	# show the frame
	frame = imutils.resize(frame, width = 320)
	hsv = imutils.resize(hsv, width = 320)
	mask = imutils.resize(mask, width = 320)
	
	cv2.imshow("Frame2", hsv)
	cv2.imshow("Frame",frame)
	cv2.imshow("Mask",mask)
	
	cv2.imwrite("/var/www/html/pic.jpg",frame)
	cv2.imwrite("/var/www/html/pic-hsv.jpg",hsv)
	cv2.imwrite("/var/www/html/pic-mask.jpg",mask)

	out = ''
	# let's wait one second before reading output (let's give device time to answer)
	time.sleep(0.1)
	while ser.inWaiting() > 0:
		out += ser.read(1)

	if out != '':
		print ">>" + out

	
	key = cv2.waitKey(1) & 0xFF

	# clear the stream in preparation for the next frame
	rawCapture.truncate(0)

	# if the `q` key was pressed, break from the loop
	if key == ord("q"):
		input = "BDA" + "ADA,.";
		ser.write(input)
		time.sleep(1)
		
		break






	

#	frame = imutils.resize(image, width = 300)

	

# cleanup the camera and close any open windows
camera.release()
cv2.destroyAllWindows()
