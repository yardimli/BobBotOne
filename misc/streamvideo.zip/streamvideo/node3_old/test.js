 var serialport = require("serialport");
 var http = require('http');
var qs = require("querystring");

const PORT=8080;

 
 var SerialPort = serialport; // localize object constructor
 var SerialPort2 = serialport; // localize object constructor

  var portName = '/dev/ttyACM0';
  var portName2 = '/dev/ttyACM1';

  var sp = new SerialPort(portName, {
     parser: serialport.parsers.readline("\r"),
     baudrate: 9600
  });

  sp.on("open", function () {
     console.log ("comm port ready");
  });

	sp.on('data', function (data) {
	  console.log('Data: ' + data);
	});




  var sp2 = new SerialPort(portName2, {
     parser: serialport.parsers.readline("\r"),
     baudrate: 9600
  });

  sp2.on("open", function () {
     console.log ("comm port 2 ready");
  });

	sp2.on('data', function (data) {
	  console.log('Data 2: ' + data);
	});


var server = http.createServer(function(req, res) {

	res.setHeader('Access-Control-Allow-Origin', '*');
	res.setHeader('Access-Control-Request-Method', '*');
	res.setHeader('Access-Control-Allow-Methods', 'OPTIONS, GET');
	res.setHeader('Access-Control-Allow-Headers', '*');
	if ( req.method === 'OPTIONS' ) {
		res.writeHead(200);
		res.end();
		return;
	}

	if (req.method == 'POST') {

		var reqBody = '';
		req.on('data', function (data) {
			reqBody += data;
			if (reqBody.length > 1e7) { //10MB
				resp.writeHead(413, 'Request Entity Too Large', { 'Content-Type': 'text/html' });
				resp.end('<!doctype html><html><head><title>413</title></head><body>413: Request Entity Too Large</body></html>');
			}
		});

		req.on('end', function () {
			var formData = qs.parse(reqBody);
			console.log(formData);
			var resultdata = [];
			if (formData.op == "pos") {
			}
			res.end(JSON.stringify(resultdata));
		});
	}

	if (req.method == 'GET') {
		var cmd = req.url;
		cmd = unescape(cmd);
		cmd = cmd.substring(1);
		
		if (cmd.substring(0,1)=="C") {
			cmd = cmd.substring(1);
			console.log(cmd);
			if (sp.isOpen()) {
				sp.write(cmd);
			} else
			{
				console.log('port is not open trying to open...');
				  sp = new SerialPort(portName, {
					 parser: serialport.parsers.readline("\r"),
					 baudrate: 9600
				  });
			}
		} else
		if (cmd.substring(0,1)=="W") {
			cmd = cmd.substring(1);
			console.log(cmd);
			if (sp2.isOpen()) {
				sp2.write(cmd);
			} else
			{
				console.log('port is not open trying to open...');
				  sp2 = new SerialPort(portName2, {
					 parser: serialport.parsers.readline("\r"),
					 baudrate: 9600
				  });
			}
		}

		res.end(req.url);
	}
}).listen(PORT,function(){
	console.log("Arduino Gateway Server listening on:... http://localhost:%s", PORT);
});


