#!/bin/bash


cd /var/www/html/node3

lxterminal -e nodejs arduino-node-server