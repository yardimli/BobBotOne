/**
 * Created by ekim on 25/4/17.
 */

var imageNr = 0; // Serial number of current image
var StopTimeout1, StopTimeout2, StopTimeout3;


//
// == Front Left Engine === Reverse: WCB + Value Fwd: WCA + value
// == Front Right Engine === Reverse: WDB + Value Fwd: WDA + value
// == Back Left Engine === Reverse: WAB + Value Fwd: WAA + value
// == Back Right Engine === Reverse: WBB + Value Fwd: WBA + value
//

//
// == Front Left Servo
// == Front Right Servo
// == Back Left Servo
// == Back Right Servo
//


var LeftPlus = 0;
var FwdPlus = 0;

var CameraPanPlus = 0;
var CameraTiltPlus = 0;

var url = window.location.href;
var arr = url.split("/");
var hostport = arr[0] + "//" + arr[2];

//-------------------------------
function SendCommand(cmdstr) {
    //$("#debugdiv").prepend(cmdstr + "<br>");

    $.get(hostport + "/robotcommand.php?" + cmdstr, function (data, status) {
//		console.log("CMD:" + cmdstr + ", Data: " + data + ", Status: " + status);
    });
}

setInterval(function () {

    var TiltTune = Number(localStorage.TiltTune);
    var PanTune = Number(localStorage.PanTune);
    var FrontLeftTune = Number(localStorage.FrontLeftTune);
    var FrontRightTune = Number(localStorage.FrontRightTune);
    var BackLeftTune = Number(localStorage.BackLeftTune);
    var BackRightTune = Number(localStorage.BackRightTune);

    var ServoStr = 'C';

    if (CameraPanPlus + PanTune > 0) {
        var SpeedValue = String.fromCharCode(65 + CameraPanPlus + PanTune);
        ServoStr += 'AE' + SpeedValue;
    }
    else if (CameraPanPlus + PanTune < 0) {
        var SpeedValue = String.fromCharCode(65 + ((CameraPanPlus + PanTune) * (-1)));
        ServoStr += 'AD' + SpeedValue;
    }
    else if (CameraPanPlus + PanTune == 0) {
        var SpeedValue = String.fromCharCode(65);
        ServoStr += 'AD' + SpeedValue;
    }

    if (CameraTiltPlus + TiltTune > 0) {
        var SpeedValue = String.fromCharCode(65 + CameraTiltPlus + TiltTune);
        ServoStr += 'BE' + SpeedValue;
    }
    else if (CameraTiltPlus + TiltTune < 0) {
        var SpeedValue = String.fromCharCode(65 + ((CameraTiltPlus + TiltTune) * (-1)));
        ServoStr += 'BD' + SpeedValue;
    }
    else if (CameraTiltPlus + TiltTune == 0) {
        var SpeedValue = String.fromCharCode(65);
        ServoStr += 'BD' + SpeedValue;
    }


    if (LeftPlus + FrontLeftTune > 0) {
        var res = String.fromCharCode(65 + LeftPlus + FrontLeftTune);
        ServoStr += 'CE' + res;
    }
    else if (LeftPlus + FrontLeftTune < 0) {
        var res = String.fromCharCode(65 + ((LeftPlus + FrontLeftTune) * (-1)));
        ServoStr += 'CD' + res;
    }
    else if (LeftPlus + FrontLeftTune == 0) {
        var res = String.fromCharCode(65);
        ServoStr += 'CD' + res;
    }

    if (LeftPlus + FrontRightTune > 0) {
        var res = String.fromCharCode(65 + LeftPlus + FrontRightTune);
        ServoStr += 'DE' + res;
    }
    else if (LeftPlus + FrontRightTune < 0) {
        var res = String.fromCharCode(65 + ((LeftPlus + FrontRightTune) * (-1)));
        ServoStr += 'DD' + res;
    }
    else if (LeftPlus + FrontRightTune == 0) {
        var res = String.fromCharCode(65);
        ServoStr += 'DD' + res;
    }

    if (LeftPlus + BackLeftTune > 0) {
        var res = String.fromCharCode(65 + LeftPlus + BackLeftTune);
        ServoStr += 'ED' + res;
    }
    else if (LeftPlus + BackLeftTune < 0) {
        var res = String.fromCharCode(65 + ((LeftPlus + BackLeftTune) * (-1)));
        ServoStr += 'EE' + res;
    }
    else if (LeftPlus + BackLeftTune == 0) {
        var res = String.fromCharCode(65);
        ServoStr += 'ED' + res;
    }

    if (LeftPlus + BackRightTune > 0) {
        var res = String.fromCharCode(65 + LeftPlus + BackRightTune);
        ServoStr += 'FD' + res;
    }
    else if (LeftPlus + BackRightTune < 0) {
        var res = String.fromCharCode(65 + ((LeftPlus + BackRightTune) * (-1)));
        ServoStr += 'FE' + res;
    }
    else if (LeftPlus + BackRightTune == 0) {
        var res = String.fromCharCode(65);
        ServoStr += 'FD' + res;
    }

    ServoStr += ',.';


    var MotorStr = "W";

    if (FwdPlus > 0) {
        var SpeedValue = String.fromCharCode(65 + FwdPlus);
        MotorStr += 'AA' + SpeedValue + 'BA' + SpeedValue + 'CA' + SpeedValue + 'DA' + SpeedValue;
    }
    else if (FwdPlus < 0) {
        var SpeedValue = String.fromCharCode(65 + (FwdPlus * (-1)));
        MotorStr += 'AB' + SpeedValue + 'BB' + SpeedValue + 'CB' + SpeedValue + 'DB' + SpeedValue;
    }
    else if (FwdPlus == 0) {
        var SpeedValue = String.fromCharCode(65);
        MotorStr += 'AB' + SpeedValue + 'BB' + SpeedValue + 'CB' + SpeedValue + 'DB' + SpeedValue;
    }

    MotorStr += ',.';

    SendCommand(ServoStr + " " + MotorStr);


}, 5000);


var c;
var ctx = null;
var ShowZoom = 1;

function findPos(obj) {
    var curleft = 0, curtop = 0;
    if (obj.offsetParent) {
        do {
            curleft += obj.offsetLeft;
            curtop += obj.offsetTop;
        } while (obj = obj.offsetParent);
        return {x: curleft, y: curtop};
    }
    return undefined;
}

function rgbToHex(r, g, b) {
    if (r > 255 || g > 255 || b > 255)
        throw "Invalid color component";
    return ((r << 16) | (g << 8) | b).toString(16);
}

var HueMinMax = [30, 40];
var SatMinMax = [40, 60];
var ValMinMax = [60, 90];
var MouseColor;
var FirstClick = true;

var imagepos = [{x: 10, y: 10}, {x: 10, y: 315}, {x: 415, y: 10}, {x: 415, y: 315}, {x: 820, y: 10}, {x: 820, y: 315}];

//-------------------------------
$(document).ready(function () {

    setInterval(function () {
        imageNr++;

        var images = [

            "http://192.168.1.15:8080/pictures/picamera_frame.jpg?n=" + imageNr,
            "http://192.168.1.15:8080/pictures/picamera_frame_hsv.jpg?n=" + imageNr,

            "http://192.168.1.16:8080/pictures/picamera_frame.jpg?n=" + imageNr,
            "http://192.168.1.16:8080/pictures/picamera_frame_hsv.jpg?n=" + imageNr,

            "http://192.168.1.14:8080/pictures/picamera_frame.jpg?n=" + imageNr,
            "http://192.168.1.14:8080/pictures/picamera_frame_hsv.jpg?n=" + imageNr];


        if (ctx !== null) {
            console.log('load image to canvas...');


            for (var i = 0; i <= images.length; i++) {

                var img = new Image();
                img.onload = (function (value) {
                    return function () {
                        ctx.drawImage(this, 0, 0, this.width, this.height, imagepos[value].x, imagepos[value].y, 400, 400 * (this.height / this.width));

                        if (ShowZoom == value + 1) {
                            //ctx.drawImage(this, 0, 0, this.width, this.height, 640, 10, 620, 620 * (this.height / this.width));
                        }
                    }
                })(i);

                // IMPORTANT - Assign src last for IE
                img.src = images[i];
            }

        }
        //	$("#webcamimg_mask").attr("src", "/pic-mask.jpg?action=snapshot&n=" + imageNr);
//	$("#webcamimg_hsv").attr("src", "/pic-hsv.jpg?action=snapshot&n=" + imageNr);
    }, 1000);

    $("#HueSlider").slider({range: true});
    $("#SatSlider").slider({range: true});
    $("#ValSlider").slider({range: true});


    $("#HueSlider").slider('setValue', HueMinMax);
    $("#SatSlider").slider('setValue', SatMinMax);
    $("#ValSlider").slider('setValue', ValMinMax);


    c = document.getElementById("myCanvas");
    ctx = c.getContext("2d");

    $("#myCanvas").click(function (e) {
        mouseX = e.pageX - $("#myCanvas").offset().left;
        mouseY = e.pageY - $("#myCanvas").offset().top;

        if (mouseX >= 0 && mouseX <= 300 && mouseY >= 0 && mouseY <= 300) {
            ShowZoom = 1;
        }
        if (mouseX >= 320 && mouseX <= 620 && mouseY >= 0 && mouseY <= 300) {
            ShowZoom = 2;
        }
        if (mouseX >= 0 && mouseX <= 300 && mouseY >= 320 && mouseY <= 620) {
            ShowZoom = 3;
        }
        if (mouseX >= 320 && mouseX <= 620 && mouseY >= 320 && mouseY <= 620) {
            ShowZoom = 4;
        }
        console.log(mouseX + " " + mouseY);

        if (mouseX >= 620) {
            if (FirstClick) {
                FirstClick = false;
                HueMinMax[0] = MouseColor[0];
                HueMinMax[1] = MouseColor[0];

                SatMinMax[0] = MouseColor[1];
                SatMinMax[1] = MouseColor[1];

                ValMinMax[0] = MouseColor[2];
                ValMinMax[1] = MouseColor[2];
            }
            else {

                if (MouseColor[0] < HueMinMax[0]) HueMinMax[0] = MouseColor[0];
                if (MouseColor[0] > HueMinMax[1]) HueMinMax[1] = MouseColor[0];

                if (MouseColor[1] < SatMinMax[0]) SatMinMax[0] = MouseColor[1];
                if (MouseColor[1] > SatMinMax[1]) SatMinMax[1] = MouseColor[1];

                if (MouseColor[2] < ValMinMax[0]) ValMinMax[0] = MouseColor[2];
                if (MouseColor[2] > ValMinMax[1]) ValMinMax[1] = MouseColor[2];
            }

            $("#HueSlider").slider('setValue', HueMinMax);
            $("#SatSlider").slider('setValue', SatMinMax);
            $("#ValSlider").slider('setValue', ValMinMax);
        }
    });

    $('#myCanvas').mousemove(function (e) {
        var pos = findPos(this);
        var x = e.pageX - pos.x;
        var y = e.pageY - pos.y;
        var coord = "x=" + x + ", y=" + y;
        MouseColor = ctx.getImageData(x, y, 1, 1).data;
        $('#status').html("Hue:" + MouseColor[0] + " Sat:" + MouseColor[1] + " Val:" + MouseColor[2] + " ");
    });

    if (localStorage.RedMin === "" || localStorage.RedMin === null) localStorage.RedMin = "0";
    if (localStorage.RedMax === "" || localStorage.RedMax === null) localStorage.RedMax = "255";
    if (localStorage.GreenMin === "" || localStorage.GreenMin === null) localStorage.GreenMin = "0";
    if (localStorage.GreenMax === "" || localStorage.GreenMax === null) localStorage.GreenMax = "255";
    if (localStorage.BlueMin === "" || localStorage.BlueMin === null) localStorage.BlueMin = "0";
    if (localStorage.BlueMax === "" || localStorage.BlueMax === null) localStorage.BlueMax = "255";


    $('input[data-arduino="RedMin"]').val(localStorage.RedMin).trigger('change');
    $('input[data-arduino="RedMax"]').val(localStorage.RedMax).trigger('change');


    $('input[data-arduino="GreenMin"]').val(localStorage.GreenMin).trigger('change');
    $('input[data-arduino="GreenMax"]').val(localStorage.GreenMax).trigger('change');


    $('input[data-arduino="BlueMin"]').val(localStorage.BlueMin).trigger('change');
    $('input[data-arduino="BlueMax"]').val(localStorage.BlueMax).trigger('change');

//	$("#FrontLeftTune").val(localStorage.FrontLeftTune);

    $('.colordial').knob({
        'release': function (v) {

            localStorage[$(this.$).data('arduino')] = Math.round(v);
            console.log($(this.$).data('arduino') + " " + Math.round(v));

            $.get("http://192.168.1.13:8080/TRedMin=" + localStorage.RedMin + ";RedMax=" + localStorage.RedMax +
                ";GreenMin=" + localStorage.GreenMin + ";GreenMax=" + localStorage.GreenMax +
                ";BlueMin=" + localStorage.BlueMin + ";BlueMax=" + localStorage.BlueMax, function (data, status) {
//		console.log("CMD:" + cmdstr + ", Data: " + data + ", Status: " + status);
            });

        }
    });


    if (localStorage.FrontRightTune == "" || localStorage.FrontRightTune == null) {
        localStorage.FrontRightTune = "0";
    }
    if (localStorage.BackLeftTune == "" || localStorage.BackLeftTune == null) {
        localStorage.BackLeftTune = "0";
    }
    if (localStorage.BackRightTune == "" || localStorage.BackRightTune == null) {
        localStorage.BackRightTune = "0";
    }
    if (localStorage.PanTune == "" || localStorage.PanTune == null) {
        localStorage.PanTune = "0";
    }
    if (localStorage.TiltTune == "" || localStorage.TiltTune == null) {
        localStorage.TiltTune = "0";
    }


    if (localStorage.FrontLeftTune == "" || localStorage.FrontLeftTune == null) {
        localStorage.FrontLeftTune = "0";
    }
    if (localStorage.FrontRightTune == "" || localStorage.FrontRightTune == null) {
        localStorage.FrontRightTune = "0";
    }
    if (localStorage.BackLeftTune == "" || localStorage.BackLeftTune == null) {
        localStorage.BackLeftTune = "0";
    }
    if (localStorage.BackRightTune == "" || localStorage.BackRightTune == null) {
        localStorage.BackRightTune = "0";
    }
    if (localStorage.PanTune == "" || localStorage.PanTune == null) {
        localStorage.PanTune = "0";
    }
    if (localStorage.TiltTune == "" || localStorage.TiltTune == null) {
        localStorage.TiltTune = "0";
    }

    $("#FrontLeftTune").val(localStorage.FrontLeftTune);
    $("#FrontRightTune").val(localStorage.FrontRightTune);
    $("#BackLeftTune").val(localStorage.BackLeftTune);
    $("#BackRightTune").val(localStorage.BackRightTune);
    $("#PanTune").val(localStorage.PanTune);
    $("#TiltTune").val(localStorage.TiltTune);


    $('.form-inline').on('submit', function () {
        return false;
    });

    $("#UpdateTuneBtn").on('click', function () {
        localStorage.FrontLeftTune = $("#FrontLeftTune").val();
        localStorage.FrontRightTune = $("#FrontRightTune").val();
        localStorage.BackLeftTune = $("#BackLeftTune").val();
        localStorage.BackRightTune = $("#BackRightTune").val();
        localStorage.PanTune = $("#PanTune").val();
        localStorage.TiltTune = $("#TiltTune").val();
    });

    $('#SendCommandBtn').on('click', function () {
        SendCommand($("#SendCommandTxt").val());
    });


    //---------------------------------------------------------------------------------------------------------------------

    key('q', function () { //camera home
        CameraPanPlus = 0;
        CameraTiltPlus = 0;
    });


//---------------------------------------------------------------------------------------------------------------------

    key('space', function () {
        LeftPlus = 0;
        SendCommand('WEEE,.');
        $('.allmotordial').val(0).trigger('change');
        $('.motordial').val(0).trigger('change');
    });

    StopTimeout3 = window.setInterval(function () {

        if (key.isPressed('d')) { //camera left
            if (CameraPanPlus > -50) CameraPanPlus--;
        }

        if (key.isPressed('a')) { //camera right
            if (CameraPanPlus < 50) CameraPanPlus++;
        }

        if (key.isPressed('s')) { //camera up
            if (CameraTiltPlus > -50) CameraTiltPlus--;
        }

        if (key.isPressed('w')) { //camera down
            if (CameraTiltPlus < 50) CameraTiltPlus++;
        }

        //--------------------------------------

        if (!key.isPressed('up') && !key.isPressed('down')) {
            if (FwdPlus > 0) FwdPlus--;
            if (FwdPlus < 0) FwdPlus++;
        }

        if (!key.isPressed('left') && !key.isPressed('right')) {
            if (LeftPlus > 0) LeftPlus--;
            if (LeftPlus < 0) LeftPlus++;
        }


        if (key.isPressed('up')) {
            if (FwdPlus < 50) FwdPlus++;
        }

        if (key.isPressed('down')) {
            if (FwdPlus > -50) FwdPlus--;
        }

        if (key.isPressed('left')) {
            if (LeftPlus < 15) LeftPlus++;
        }

        if (key.isPressed('right')) {
            if (LeftPlus > -15) LeftPlus--;
        }
    }, 50);


//---------------------------------------------------------------------------------------------------------------------

    $('#RotateAllTires').on('click', function () {
        SendCommand('C' + 'CCZ' + 'DBZ' + 'EBZ' + 'FCZ' + ',.');
    });


    $('#CameraCenter').on('click', function () {
        SendCommand('CAAABAA,.');
    });

    $("#AllStop").on('click', function () {
        SendCommand('WEEE,.');
        $('.allmotordial').val(0).trigger('change');
        $('.motordial').val(0).trigger('change');
    });

    $(".knob").knob({
        change: function (value) {
            //console.log("change : " + value);
        },
        release: function (value) {
        },
        cancel: function () {
            console.log("cancel : ", this);
        },
        /*format : function (value) {
         return value + '%';
         },*/
    });


})
;

