# USAGE
# python cam.py --face cascades/haarcascade_frontalface_default.xml
# python cam.py --face cascades/haarcascade_frontalface_default.xml --video video/adrian_face.mov

# import the necessary packages
from pyimagesearch.facedetector import FaceDetector
from pyimagesearch import imutils

from picamera.array import PiRGBArray
from picamera import PiCamera

import argparse
import cv2

import serial
import time
import string
import random

ser = serial.Serial('/dev/ttyACM1', 115200)




# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-f", "--face", required = True,
	help = "path to where the face cascade resides")
ap.add_argument("-v", "--video",
	help = "path to the (optional) video file")
args = vars(ap.parse_args())

# construct the face detector
fd = FaceDetector(args["face"])

# camera = cv2.VideoCapture(0)

camera = PiCamera()
camera.resolution = (640, 480)
camera.framerate = 32
rawCapture = PiRGBArray(camera, size=(640, 480))

goleft =0
goright = 0
goup = 0
godown = 0

# keep looping
for frameX in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
	frame = frameX.array


	# resize the frame and convert it to grayscale
	frame = imutils.resize(frame, width = 320)
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	faceRects = fd.detect(gray, scaleFactor = 1.1, minNeighbors = 5, minSize = (30, 30))

	maxArea = 0  
	x = 0  
	y = 0  
	w = 0  
	h = 0

	for (_x,_y,_w,_h) in faceRects:  
		if  _w*_h > maxArea:
			x = _x
			y = _y
			w = _w
			h = _h
			maxArea = w*h
	
	if maxArea > 0 :
		cv2.rectangle(frame,  (x-10, y-20), (x + w+10 , y + h+20), (255,0,0),2)
		
		centerface_horz = x+(w/2)
		cv2.rectangle(frame,(x-5,y-38),(x+35,y-10),(0,0,0),cv2.FILLED)
		cv2.putText(frame, str(centerface_horz), (x, y-20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255),1)
		direction = "C"
		if centerface_horz > 165 :
			jump = centerface_horz-160
			jump = (jump / 10)
			if (jump>3) : jump = 3
			goleft = goleft+jump
			direction = "L"
			if goleft>0 :
				input = "BDF" + "AD" + chr(65+goleft) +",.";
			if goleft<0 :
				input = "BDF" + "AE" + chr(65+goleft) +",.";
				
			ser.write(input)

			#time.sleep(0.2)
		if centerface_horz < 155 :
			jump = 160-centerface_horz
			jump = (jump / 10)
			if (jump>3) : jump = 3
			goleft = goleft - jump
			direction = "R"
			if goleft>0 :
				input = "BDF" + "AD" + chr(65+goleft) +",.";
			if goleft<0 :
				input = "BDF" + "AE" + chr(65+goleft) +",.";
			
			ser.write(input)

			
			#time.sleep(0.2)
		cv2.rectangle(frame,(10,5),(70,25),(0,0,0),cv2.FILLED)
		cv2.putText(frame, direction+" "+str(goleft), (14, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255),1)
	else:
		goleft = 0
		input = "BDF" + "AE" + chr(65+0) +",.";
		ser.write(input)
		

	# show our detected faces
	cv2.imshow("Face", frame)
	cv2.imwrite("/var/www/html/pic.jpg",frame)

	# if the 'q' key is pressed, stop the loop
	if cv2.waitKey(1) & 0xFF == ord("q"):
		break

	rawCapture.truncate(0)
	
	out = ''
	# let's wait one second before reading output (let's give device time to answer)
	time.sleep(0.1)
	while ser.inWaiting() > 0:
		out += ser.read(1)

	if out != '':
		print ">>" + out

	

# cleanup the camera and close any open windows
camera.release()
cv2.destroyAllWindows()
