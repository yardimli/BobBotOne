'''
		if (y+(h/2)) > 140 :
			goup = 0
			godown = godown+1
			input = "BDF" + "BD" + chr(65+godown) +",.";
			ser.write(input)
			cv2.putText(frame, "down "+ str( ( (x+(w/2))-120) / 20), (10, 180), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 1)
			#time.sleep(0.2)
		if (y+(h/2)) < 100 :
			godown = 0
			goup = goup + 1
			# chr(65+ ( ( (x+(w/2))) / 20) )
			input = "BDF" + "BE" + chr(65+goup) +",.";
			ser.write(input)
			cv2.putText(frame, "up "+ str( ( (x+(w/2))) / 20), (10, 180), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 1)
			#time.sleep(0.2)

'''
	# loop over the face bounding boxes and draw them
#	for (fX, fY, fW, fH) in faceRects:
#		cv2.rectangle(frame, (fX, fY), (fX + fW, fY + fH), (0, 255, 0), 2)
		

