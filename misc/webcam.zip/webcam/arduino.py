import serial
import time
import string
import random

ser = serial.Serial('/dev/ttyACM1', 115200)


input=1
while 1 :
    # get keyboard input
    #input = raw_input(">> ")
        # Python 3 users
        # input = input(">> ")
    #if input == 'exit':
    #    ser.close()
    #    exit()
    #else:
	input = random.choice('ABCDEF')+random.choice('DE')+random.choice(string.ascii_uppercase)+',.';
		
        # send the character to the device
        # (note that I happend a \r\n carriage return and line feed to the characters - this is requested by my device)
        ser.write(input)
        out = ''
        # let's wait one second before reading output (let's give device time to answer)
        time.sleep(0.1)
        while ser.inWaiting() > 0:
            out += ser.read(1)

        if out != '':
            print ">>" + out

#while True:
#  print ser.readline()

