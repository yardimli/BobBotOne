#!/usr/bin/env python
from setuptools import setup, find_packages

setup(
    name = "pyfisheye",
    version = "0.0.1",
    author='Amit Aides',
    author_email='amitaid@campus.technion.ac.il',
    packages=find_packages(),
    scripts=[]
)