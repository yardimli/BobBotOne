<?php

$file = "/var/www/html/color.dat";
if (!unlink($file))
  {
  echo ("Error deleting $file");
  }
else
  {
  echo ("Deleted $file");
  }
  
  file_put_contents($file,$_GET["colorstr"]);
  
  
?>

